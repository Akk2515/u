package com.example.asphaltbridge

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var container: LinearLayout
    private lateinit var server: EditText
    private lateinit var bridge: BleBridge

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasPermissions()) scan() else status.text = "Bluetooth permission denied."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.statusText)
        output = findViewById(R.id.outputText)
        container = findViewById(R.id.deviceContainer)
        server = findViewById(R.id.serverUrl)

        bridge = BleBridge(
            this,
            { s -> runOnUiThread { status.text = s } },
            { devices -> runOnUiThread { showDevices(devices) } },
            { text -> runOnUiThread { output.text = text } }
        )

        findViewById<Button>(R.id.scanButton).setOnClickListener {
            if (hasPermissions()) scan() else permissions.launch(requiredPermissions())
        }
        findViewById<Button>(R.id.disconnectButton).setOnClickListener { bridge.disconnect() }
    }

    private fun scan() {
        bridge.serverUrl = server.text.toString().trim().removeSuffix("/")
        bridge.scan()
    }

    private fun showDevices(devices: List<BleBridge.FoundDevice>) {
        container.removeAllViews()
        if (devices.isEmpty()) {
            val t = TextView(this)
            t.text = "No likely Asphalt devices found."
            t.setTextColor(0xFFCCCCCC.toInt())
            container.addView(t)
            return
        }
        devices.forEach { d ->
            val b = Button(this)
            b.text = "${d.name}\n${d.address}  RSSI ${d.rssi}"
            b.setOnClickListener { bridge.connect(d.device) }
            container.addView(b)
        }
    }

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasPermissions() =
        requiredPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onDestroy() {
        bridge.disconnect()
        super.onDestroy()
    }
}
