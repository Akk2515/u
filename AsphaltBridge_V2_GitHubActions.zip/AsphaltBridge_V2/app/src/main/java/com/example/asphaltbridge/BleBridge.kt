package com.example.asphaltbridge

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import okhttp3.*
import org.json.JSONObject
import java.util.UUID

class BleBridge(
    private val context: Context,
    private val onStatus: (String) -> Unit,
    private val onDevices: (List<FoundDevice>) -> Unit,
    private val onOutput: (String) -> Unit
) {
    data class FoundDevice(val device: BluetoothDevice, val name: String, val rssi: Int)

    private val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter get() = manager.adapter
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private val found = linkedMapOf<String, FoundDevice>()
    private val handler = Handler(Looper.getMainLooper())
    private val http = OkHttpClient()
    var serverUrl = "http://192.168.1.100:8000"

    @SuppressLint("MissingPermission")
    fun scan() {
        if (adapter == null || !adapter.isEnabled) {
            onStatus("Turn Bluetooth ON.")
            return
        }
        stopScan()
        found.clear()
        onDevices(emptyList())
        scanner = adapter.bluetoothLeScanner
        onStatus("Scanning for Asphalt / Fire-Boltt...")
        scanner?.startScan(
            null,
            ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),
            callback
        )
        handler.postDelayed({
            stopScan()
            onDevices(found.values.toList())
            onStatus(if (found.isEmpty()) "No matching watch found." else "Select a device.")
        }, 15000)
    }

    @SuppressLint("MissingPermission")
    private val callback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val d = result.device
            val name = d.name ?: result.scanRecord?.deviceName ?: "Unknown"
            val n = name.lowercase()
            if (n.contains("asphalt") || n.contains("fire-boltt") ||
                n.contains("firebolt") || n.contains("fire boltt") ||
                n.contains("da fit") || n.contains("dafit")) {
                found[d.address] = FoundDevice(d, name, result.rssi)
                onDevices(found.values.toList())
            }
        }
        override fun onScanFailed(code: Int) { onStatus("Scan failed: $code") }
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        stopScan()
        gatt?.close()
        onStatus("Connecting to ${device.name ?: device.address}...")
        gatt = device.connectGatt(context, false, callbackGatt, BluetoothDevice.TRANSPORT_LE)
    }

    private val callbackGatt = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                onStatus("Connected. Discovering services...")
                g.discoverServices()
                send(JSONObject().put("type","connected").put("address",g.device.address))
            } else {
                onStatus("Disconnected (status=$status).")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                onStatus("GATT discovery failed: $status"); return
            }
            val sb = StringBuilder()
            sb.append("DEVICE: ${g.device.name ?: g.device.address}\n\n")
            for (s in g.services) {
                sb.append("SERVICE ${s.uuid}\n")
                for (c in s.characteristics) {
                    sb.append("  CHAR ${c.uuid} [${props(c)}]\n")
                    if (c.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) {
                        try { g.readCharacteristic(c) } catch (_: Exception) {}
                    }
                    if (c.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or
                                BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                        enableNotify(g, c)
                    }
                }
            }
            onOutput(sb.toString())
            onStatus("GATT ready. Notifications enabled where possible.")
        }

        @Deprecated("API 32 callback")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            handle(c, c.value ?: ByteArray(0), "notify")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            handle(c, value, "notify")
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) handle(c, value, "read")
        }
    }

    @SuppressLint("MissingPermission")
    private fun enableNotify(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
        if (!g.setCharacteristicNotification(c, true)) return
        val d = c.getDescriptor(UUID.fromString(CCC))
        if (d != null) {
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }
    }

    private fun props(c: BluetoothGattCharacteristic): String {
        val p = mutableListOf<String>()
        if (c.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) p += "READ"
        if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) p += "WRITE"
        if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) p += "WRITE_NO_RESPONSE"
        if (c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) p += "NOTIFY"
        if (c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) p += "INDICATE"
        return p.joinToString(",")
    }

    private fun handle(c: BluetoothGattCharacteristic, bytes: ByteArray, source: String) {
        val hex = bytes.joinToString(" ") { "%02X".format(it.toInt() and 255) }
        onOutput("RX ${c.uuid}\n$hex\n\n")
        send(JSONObject()
            .put("type","ble_packet")
            .put("source",source)
            .put("characteristic",c.uuid.toString())
            .put("data_hex",hex)
            .put("data_length",bytes.size)
            .put("timestamp",System.currentTimeMillis()))
    }

    private fun send(json: JSONObject) {
        val body = json.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url("$serverUrl/api/ble").post(body).build()
        http.newCall(request).enqueue(object: Callback {
            override fun onFailure(call: Call, e: java.io.IOException) {
                handler.post { onStatus("Watch connected, but Python server unavailable.") }
            }
            override fun onResponse(call: Call, response: Response) { response.close() }
        })
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        stopScan()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        onStatus("Disconnected.")
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        try { scanner?.stopScan(callback) } catch (_: Exception) {}
        scanner = null
    }

    companion object { const val CCC = "00002902-0000-1000-8000-00805f9b34fb" }
}
